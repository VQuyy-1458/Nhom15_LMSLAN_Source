#include <iostream>
int main() { int n; std::cin >> n; int s = 0; for (int i=2;i<=n;i+=2) s+=i; std::cout << s; }
