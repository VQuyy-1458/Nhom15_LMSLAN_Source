File dùng để thử thao tác nộp bài. Có thể đổi nội dung và nộp lại để xem lịch sử.
