Bài nộp mẫu: DEMO004
Bài tập 05 – Con trỏ và quản lý bộ nhớ
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
