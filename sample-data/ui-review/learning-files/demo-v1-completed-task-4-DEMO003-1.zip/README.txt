Bài nộp mẫu: DEMO003
Bài tập 04 – Hàm và tổ chức chương trình
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
