Bài nộp mẫu: DEMO011
Bài tập 01 – Khảo sát mô hình TCP/IP và công cụ mạng
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
