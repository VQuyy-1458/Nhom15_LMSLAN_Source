Bài nộp mẫu: DEMO002
Bài tập 10 – Bài tập tổng hợp cuối học phần
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
