Bài nộp mẫu: DEMO011
Bài tập 01 – Phân tích yêu cầu và mô hình ERD
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
