Bài nộp mẫu: DEMO013
Bài tập 02 – Chuẩn hóa dữ liệu đến dạng 3NF
Lần nộp: 2
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
