Bài nộp mẫu: DEMO002
Bài tập 06 – Lập trình hướng đối tượng
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
