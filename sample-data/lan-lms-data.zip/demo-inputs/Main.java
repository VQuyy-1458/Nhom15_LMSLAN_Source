import java.util.*;
class SinhVien {
  private static int count=0;
  private String maSV, hoTen, lop, ns;
  private double gpa;
  public SinhVien(String name,String klass,String birth,double score) {
    maSV=String.format("B20DCCN%03d",++count);
    StringBuilder b=new StringBuilder();
    for(String word:name.trim().split("\s+")) b.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1).toLowerCase()).append(' ');
    hoTen=b.toString().trim(); lop=klass; String[] p=birth.trim().split("/");
    ns=String.format("%02d/%02d/%s",Integer.parseInt(p[0]),Integer.parseInt(p[1]),p[2]); gpa=score;
  }
  public double getGpa(){return gpa;}
  public String toString(){return String.format("%s %s %s %s %.2f",maSV,hoTen,lop,ns,gpa);}
}
public class Main {
  public static void main(String[] args){Scanner sc=new Scanner(System.in); int n=Integer.parseInt(sc.nextLine()); List<SinhVien> a=new ArrayList<>();
    for(int i=0;i<n;i++){String name=sc.nextLine(),klass=sc.nextLine(),birth=sc.nextLine();double score=Double.parseDouble(sc.nextLine());a.add(new SinhVien(name,klass,birth,score));}
    a.sort((x,y)->Double.compare(y.getGpa(),x.getGpa()));for(SinhVien s:a)System.out.println(s);
  }
}
