import socket
with socket.socket() as server:
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', 9000))
    server.listen()
    connection, address = server.accept()
    with connection:
        data = connection.recv(4096)
        connection.sendall(data)
