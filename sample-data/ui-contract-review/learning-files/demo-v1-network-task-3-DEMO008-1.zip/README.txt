Bài nộp mẫu: DEMO008
Bài tập 03 – Giao tiếp UDP và xử lý mất gói
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
