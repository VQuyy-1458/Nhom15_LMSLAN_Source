Bài nộp mẫu: DEMO016
Bài tập 03 – Thiết kế lược đồ và ràng buộc toàn vẹn
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
