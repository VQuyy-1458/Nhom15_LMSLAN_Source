Bài nộp mẫu: DEMO002
Bài tập 04 – Truyền file an toàn trong mạng LAN
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
