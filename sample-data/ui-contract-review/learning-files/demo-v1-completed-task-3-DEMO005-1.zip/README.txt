Bài nộp mẫu: DEMO005
Bài tập 03 – Mảng, chuỗi và xử lý dữ liệu
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
