Bài nộp mẫu: DEMO013
Bài tập 04 – Truy vấn JOIN trên nhiều bảng
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
