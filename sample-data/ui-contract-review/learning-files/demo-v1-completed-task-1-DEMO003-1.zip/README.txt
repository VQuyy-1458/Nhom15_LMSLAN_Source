Bài nộp mẫu: DEMO003
Bài tập 01 – Biến, kiểu dữ liệu và nhập xuất
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
