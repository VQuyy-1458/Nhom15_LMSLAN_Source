Bài nộp mẫu: DEMO012
Bài tập 02 – Chuẩn hóa dữ liệu đến dạng 3NF
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
