Bài nộp mẫu: DEMO008
Bài tập 02 – Cấu trúc rẽ nhánh và vòng lặp
Lần nộp: 1
Đây là dữ liệu kiểm thử, không phải kết quả của sinh viên thật.
